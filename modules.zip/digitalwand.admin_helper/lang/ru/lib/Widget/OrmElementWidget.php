<?php

$MESS['TITLE_FIELD_NAME'] = 'Элемент не найден';