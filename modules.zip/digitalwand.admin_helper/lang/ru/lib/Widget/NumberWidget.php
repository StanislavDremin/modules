<?php
$MESS['VALUE_IS_NOT_NUMERIC'] = 'Поле #FIELD# должно содержать число';