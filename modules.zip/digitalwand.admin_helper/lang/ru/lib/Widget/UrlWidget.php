<?php
$MESS['PROTOCOL_REQUIRED'] = 'Укажите протокол ссылки "#FIELD#" (например http://)';