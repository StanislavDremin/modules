<?php

$MESS['DIGITALWAND_ADMIN_HELPER_GETMODEL_EXCEPTION'] = 'Попыка обращение к несуществующему HL-инфоблоку #CLASS#';
$MESS['DIGITALWAND_ADMIN_HELPER_ACCESS_FORBIDDEN'] = 'Доступ запрещен';