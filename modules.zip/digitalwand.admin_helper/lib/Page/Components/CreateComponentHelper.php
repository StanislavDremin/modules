<?php
/**
 * Created by OOO 1C-SOFT.
 * User: dremin_s
 * Date: 14.03.2017
 */
namespace DigitalWand\AdminHelper\Page\Components;

use DigitalWand\AdminHelper\Helper;

class CreateComponentHelper extends Helper\AdminEditHelper
{
	static public $module = 'digitalwand.admin_helper';
	protected static $model = '';

	public static $titlePage = 'Создание компонента';

}