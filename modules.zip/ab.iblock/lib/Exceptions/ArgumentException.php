<?php
/**
 * Created by PhpStorm.
 * User: dremin_s
 * Date: 26.07.2016
 * Time: 12:58
 */

namespace AB\Iblock\Exceptions;

use Bitrix\Main;

class ArgumentException extends Main\ArgumentException
{

}