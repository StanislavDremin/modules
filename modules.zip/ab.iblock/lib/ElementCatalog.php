<?php
/**
 * Created by PhpStorm.
 * User: dremin_s
 * Date: 28.07.2016
 * Time: 12:24
 */

namespace AB\Iblock;
use Bitrix\Main\Entity;

class ElementCatalog extends Element
{

}