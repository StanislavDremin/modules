<?
$arModuleVersion = array(
	"VERSION" => "4.0.0",
	"VERSION_DATE" => "2016-07-26 12:00:00",
);