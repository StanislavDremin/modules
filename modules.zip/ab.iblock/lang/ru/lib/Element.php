<?php
$MESS['AB_THIS_IBLOCK_ID_IS_NOT_EXIST'] = 'Инфоблока с номером #ID# не существует';