<?php
$MESS ['AB_IBLOCK_INSTALL_NAME'] = "Новый ORM для инфоблоков";
$MESS ['AB_IBLOCK_INSTALL_DESCRIPTION'] = "";
$MESS ['AB_PARTNER_NAME'] = 'ООО 1С-СОФТ';