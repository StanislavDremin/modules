<?php
$MESS['HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_EDIT'] = 'Блок "#NAME#": Редактирование записи ##NUM#';
$MESS['HLBLOCK_ADMIN_ENTITY_ROW_EDIT_PAGE_TITLE_NEW'] = 'Блок "#NAME#": Создание записи';
$MESS['HLBLOCK_ADMIN_ROW_EDIT_NOT_FOUND'] = 'Информация о Блоке не найдена';
$MESS['PW_HL_EDIT_LOG_TAB'] = 'История изменений';