<?php
$MESS['PW_HL_MENU_MAIN'] = 'Справочники';