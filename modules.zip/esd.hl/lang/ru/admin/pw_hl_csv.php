<?php
$MESS['PW_HL_ADMIN_CSV_TITLE'] = 'Импорт из CSV';