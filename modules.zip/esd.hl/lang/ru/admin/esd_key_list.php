<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/local/modules/esd.hl/lang/ru/admin/pw_hl_row_list.php');