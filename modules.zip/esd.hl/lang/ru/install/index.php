<?
$MESS ['ESD_HL_INSTALL_NAME'] = "Модуль HL";
?>