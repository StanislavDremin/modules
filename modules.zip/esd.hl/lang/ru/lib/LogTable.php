<?php
$MESS['LOG_ENTITY_ID_FIELD'] = 'ID';
$MESS['LOG_ENTITY_ELEMENT_ID_FIELD'] = 'ID элемента';
$MESS['LOG_ENTITY_USER_X_FIELD'] = 'Кто изменил';
$MESS['LOG_ENTITY_FIELDS_FIELD'] = 'Список изменений';
$MESS['LOG_ENTITY_DATE_X_FIELD'] = 'Когда изменили';
$MESS['LOG_ENTITY_VERSION_FIELD'] = 'Версия';
$MESS['PW_HL_NEW_LOG_ELEMENT'] = 'Элемент создан';
$MESS['LOG_ENTITY_ENTITY_ID_FIELD'] = 'HL-блок';