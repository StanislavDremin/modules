<?php
$MESS['EHL_OPT_MENU'] = 'Меню';
$MESS['EHL_OPT_FIELDS'] = 'Поля HL';
$MESS['EHL_OPT_RIGHT'] = 'Доступ';
$MESS['EHL_OPT_BLOCK_TBL_NAV'] = 'HL-блоки';
$MESS['EHL_OPT_BLOCK_HEAD_NAME'] = 'Сущность';
$MESS['EHL_OPT_BLOCK_HEAD_TITLE'] = 'Название';
$MESS['EHL_OPT_BLOCK_HEAD_MENU'] = 'Меню';
$MESS['EHL_OPT_LOG'] = 'Логирование';