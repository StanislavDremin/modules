<?
$arModuleVersion = array(
	"VERSION" => "3.0.0",
	"VERSION_DATE" => "2016-11-22 12:12:12",
);
