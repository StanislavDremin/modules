<?php
/**
 * Created by OOO 1C-SOFT.
 * User: dremin_s
 * Date: 22.11.2016
 */

namespace Online1c\Iblock;


class HelperIblock
{
	const CACHE_META_PROP_TIME = 2592000; // 30 ����
	const CACHE_META_PROP_FOLDER = '/online1c/iblock/props';
	const CACHE_META_PROP_ID = 'metaProp_';




}