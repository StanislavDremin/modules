<?php
$MESS['ONLINE_1C_IBLOCK_INSTALL_NAME'] = 'Инфоблоки 3.0';
$MESS['ONLINE_1C_IBLOCK_INSTALL_DESC'] = 'Расширенная поддержка ORM для инфблоков';