<?
namespace Online1c\Reviews\EventHandlers;

use Bitrix\Main\Localization;
Localization\Loc::loadMessages(__FILE__);

class OnAfterIBlockElementUpdateHandler{
	static public function handler(&$arFields){
		
	}

}