<?php
$MESS['O1C_REVIEW_CMP.NAME_BLOCK'] = 'Отзывы';