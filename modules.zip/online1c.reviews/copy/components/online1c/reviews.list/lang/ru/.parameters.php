<?php
$MESS['O1C_REVIEW_PARAMS.TYPE_ID'] = 'Тип отзывов';
$MESS['O1C_REVIEW_PARAMS.ELEMENT_CODE'] = 'ИД элемента';
$MESS['O1C_REVIEW_PARAMS.SHOW_AVATARS'] = 'Показывать аватарки комментаторов';
$MESS['O1C_REVIEW_PARAMS.PREMODERATE'] = 'Отзывы с премодерацией';
$MESS['O1C_REVIEW_PARAMS.FIELDS'] = 'Поля, выводимые в форме добавления нового отзыва';
$MESS['O1C_REVIEW_PARAMS.REQUIRED_FIELDS'] = 'Обязательные поля для формы';
$MESS['O1C_REVIEW_PARAMS.ONLY_AUTH'] = 'Только зарегистрированные пользователи могут комментировать';
$MESS['O1C_REVIEW_PARAMS.LIST_ONLY'] = 'Показать только список отзывов, без возможности комментирования';
$MESS['O1C_REVIEW_PARAMS.SHOW_LIKES'] = 'Показать иконки лайков';
$MESS['O1C_REVIEW_PARAMS.DISLIKE_START'] = 'С какого количества лайков можно разрешать ставить дизлайки';
$MESS['O1C_REVIEW_PARAMS.SYSTEM_AUTH_TEMPLE'] = 'Шаблон компонента авторизации';
