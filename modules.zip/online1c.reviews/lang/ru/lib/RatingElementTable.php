<?php
$MESS['O1C_REVIEW_RATING.ELEMENT_CODE'] = 'Элемент';
$MESS['O1C_REVIEW_RATING.REVIEW_COUNT'] = 'Количество элементов';