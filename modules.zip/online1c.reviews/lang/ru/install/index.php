<?
$MESS["ONLINE1C_REVIEWS_MODULE_NAME"] = "Отзывы";
$MESS["ONLINE1C_REVIEWS_MODULE_DESC"] = "Создание, вывод, модерация отзывов к любому контенту";
$MESS["ONLINE1C_REVIEWS_PARTNER_NAME"] = "online1c";
$MESS["ONLINE1C_REVIEWS_PARTNER_URI"] = "http://esd.1c.ru";
$MESS["ONLINE1C_REVIEWS_INSTALL"] = "Установка модуля \"Отзывы\"";
$MESS["ONLINE1C_REVIEWS_UNINSTALL"] = "Деинсталяция модуля \"Отзывы\"";
$MESS["ONLINE1C_REVIEWS_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 14. Не поддерживается технология D7. Пожалуйста обновите систему.";
?>