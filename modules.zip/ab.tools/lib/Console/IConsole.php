<?php
/**
 * Created by OOO 1C-SOFT.
 * User: teacher
 * Date: 24.11.16
 */

namespace AB\Tools\Console;


interface IConsole
{

	public function description();

	public function run();

}