<?php
/**
 * Created by OOO 1C-SOFT.
 * User: dremin_s
 * Date: 20.02.2017
 */

namespace AB\Tools\Helpers;


class MainHelper
{
	const ASSET_FOLDER = '/local/modules/ab.tools/asset';
}