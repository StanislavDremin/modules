<?php
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_BASE'] = 'Основные настройки';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_EMAIL'] = 'Отправка почты';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_AUTO_INSERT'] = 'Автоподставнока данных для зареистрированных пользователей';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_RENAMES'] = 'Переименование полей';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_IBLOCK_TYPE'] = 'Тип инфоблока';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_IBLOCK_ID'] = 'ID инфоблока';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_FORM_ID'] = 'ID формы';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_FORM_NAME_BLOCK'] = 'Название блока формы';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_FORM_NAME_BLOCK_DEFAULT'] = 'Обратная связь';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_BTN_SAVE'] = 'Название кнопки сохранения';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_BTN_SAVE_DEFAULT'] = 'Отправить';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_EMAIL_EVENT'] = 'Шаблон почтового сообщения';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_EMAIL_ADMIN'] = 'E-mail-ы администраторов(можно несколько через запятую)';
$MESS['AB_TOOLS_FORM_IBLOCK_C_PARAM_GOOD_MESSAGE'] = 'Сообщение в случае успешного сохранения формы';