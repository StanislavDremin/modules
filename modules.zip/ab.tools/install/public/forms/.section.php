<?
$sSectionName = "Новый раздел";
$arDirProperties = Array(

);
?>