/**
 * Created by dremin_s on 16.03.2017.
 */
/** @var o React */
/** @var o ReactDOM */
/** @var o is */
/** @var o $ */
"use strict";

export default {
	formSubmitEv: 'FORM_SUBMIT_'
};