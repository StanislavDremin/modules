<?php
$MESS ['AB_TOOLS_INSTALL_NAME'] = "Утилиты";
$MESS['AB_PARTNER_NAME'] = '1C СОФТ';